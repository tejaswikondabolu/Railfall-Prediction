import streamlit as st
import requests
from datetime import datetime

# API key and list of cities
API_KEY = '2e0dd887d68875346b419190ffa358ed'
cities = sorted(['Amaravathi', 'Guntur', 'Machilipatnam', 'Mangalagiri', 'Nandigama', 'Tenali', 'Vijayawada'])

# Sidebar selection for city
CITY = f"{st.sidebar.selectbox('Select a city in the Vijayawada area', cities)}, IN"

# CSS for styling
st.markdown("""
    <style>
    .weather-card {
        background-color: rgba(0, 0, 0, 0.6);
        padding: 20px;
        margin-bottom: 20px;
        border-radius: 10px;
        color: white;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .weather-icon {
        width: 50px;
        height: 50px;
    }
    </style>
""", unsafe_allow_html=True)

# Title
st.title("Rainfall Prediction App - Vijayawada Areas")

# Icon mapping for weather
icon_mapping = {
    'Rain': 'https://img.icons8.com/ios-filled/50/ffffff/rain.png',
    'Clear': 'https://img.icons8.com/ios-filled/50/ffffff/sun.png',
    'Clouds': 'https://img.icons8.com/ios-filled/50/ffffff/cloud.png',
}

# Function to fetch weather data
def fetch_weather_data(api_key, city):
    url = f"http://api.openweathermap.org/data/2.5/forecast?q={city}&units=metric&appid={api_key}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        st.error(f"Error: Could not fetch data for {city}. Status code {response.status_code}")
        return None

# Farm-friendly explanation function
def generate_farm_friendly_explanation(temp_min, temp_max, humidity, wind_speed, prediction):
    explanation = f"*Weather Prediction: {prediction}*\n\n"

    # Humidity Explanation
    if humidity > 85:
        explanation += f"High humidity ({humidity}%). Rain likely. Farmers should ensure field drainage."
    elif 65 <= humidity <= 85:
        explanation += f"Moderate humidity ({humidity}%), beneficial rain likely."
    elif 45 <= humidity < 65:
        explanation += f"Moderate humidity ({humidity}%), light rain may occur."
    else:
        explanation += f"Low humidity ({humidity}%). Rain unlikely, consider irrigation."

    # Min Temperature Explanation
    if temp_min < 10:
        explanation += f"\n\nLow temp ({temp_min}°C) might risk frost for sensitive crops."
    elif 10 <= temp_min <= 20:
        explanation += f"\n\nModerate low temp ({temp_min}°C), stable conditions expected."
    else:
        explanation += f"\n\nWarmer low temp ({temp_min}°C), limited dew, soil may dry."

    # Max Temperature Explanation
    if temp_max < 20:
        explanation += f"\n\nCool max temp ({temp_max}°C), gentle rain likely."
    elif 20 <= temp_max <= 30:
        explanation += f"\n\nModerate max temp ({temp_max}°C), steady rain, should dry quickly."
    else:
        explanation += f"\n\nHigh max temp ({temp_max}°C), intense rain possible."

    # Wind Speed Explanation
    if wind_speed < 5:
        explanation += f"\n\nLow wind speed ({wind_speed} km/h), rain likely to fall steadily."
    elif 5 <= wind_speed <= 15:
        explanation += f"\n\nModerate wind speed ({wind_speed} km/h), steady rain without extreme gusts."
    else:
        explanation += f"\n\nHigh wind speed ({wind_speed} km/h), possible heavy rain with gusts."

    return explanation

# Fetch weather data
weather_data = fetch_weather_data(API_KEY, CITY)

# Display forecast data if available
if weather_data and 'list' in weather_data:
    st.write(f'Weather forecast for the next 7 days in {CITY}:')

    # Group forecast data by date
    daily_data = {}
    for forecast in weather_data['list']:
        forecast_datetime = datetime.strptime(forecast['dt_txt'], '%Y-%m-%d %H:%M:%S')
        date_str = forecast_datetime.strftime('%Y-%m-%d')
        if date_str not in daily_data:
            daily_data[date_str] = []
        daily_data[date_str].append(forecast)

    # User selects a date to view hourly forecasts
    selected_date = st.selectbox("Select a date to view hourly predictions", list(daily_data.keys())[:7])

    # Display each 3-hour forecast for the selected date
    st.write(f"Hourly predictions for {selected_date}:")
    for forecast in daily_data[selected_date]:
        hourly_datetime = datetime.strptime(forecast['dt_txt'], '%Y-%m-%d %H:%M:%S')
        temp_min = forecast['main']['temp_min']
        temp_max = forecast['main']['temp_max']
        humidity = forecast['main']['humidity']
        windspeed = forecast['wind']['speed']
        weather_description = forecast['weather'][0]['main']  # Short description like "Rain" or "Clear"

        # Get icon based on weather description
        icon_url = icon_mapping.get(weather_description, 'https://img.icons8.com/ios-filled/50/ffffff/question-mark.png')

        # Generate farm-friendly explanation
        farm_explanation = generate_farm_friendly_explanation(temp_min, temp_max, humidity, windspeed, weather_description)

        # Display each hourly forecast in a styled card
        st.markdown(f"""
            <div class="weather-card">
                <div>
                    <strong>Time: {hourly_datetime.strftime('%H:%M:%S')}</strong><br>
                    Temp Min: {temp_min}°C<br>
                    Temp Max: {temp_max}°C<br>
                    Humidity: {humidity}%<br>
                    Wind Speed: {windspeed} km/h<br>
                    Prediction: {weather_description}<br><br>
                    <strong>Farmer's Note:</strong><br>
                    {farm_explanation}
                </div>
                <div>
                    <img src="{icon_url}" class="weather-icon">
                </div>
            </div>
        """, unsafe_allow_html=True)
else:
    st.write('Error fetching weather data. Please check your API key and city name.')
